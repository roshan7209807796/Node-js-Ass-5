const express = require("express");
const app = express();

//importing contact and welcome from routes
const welcome = require('./routes/welcome');
const contact = require('./routes/contact');


let port = process.env.PORT || 8081;

//routes

//welcomepage
app.use('/welcome', welcome);

//contact 
app.use('/contact', contact);

//error for all other page
app.get('*', (req, res) => {
    res.sendStatus(404);
});


app.listen(port, () => {
    console.log(`app is running at port: ${port}.....`);
})
