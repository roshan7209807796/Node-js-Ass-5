const route = require('express').Router();

route.get('/', (req, res) => {
    res.status(200).send('<h1> Welcome to Dominos! </h1> ');
})

module.exports = route;