const route = require('express').Router();

route.get('/', (req, res) => {
    res.status(200).json(
        {
            phone: '18602100000',
            email: 'guestcaredominos@jublfood.com'
        }
    )
})

module.exports = route;